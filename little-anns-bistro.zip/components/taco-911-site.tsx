import Image from 'next/image'
import {
  ArrowDown,
  ArrowUpRight,
  Clock3,
  Flame,
  MapPin,
  Phone,
  Sparkles,
} from 'lucide-react'

const mapUrl =
  'https://www.google.com/maps/search/?api=1&query=106%20E%206th%20St%2C%20Austin%2C%20TX'

const tacos = [
  {
    name: 'Carne Asada',
    description: 'Grilled steak, onion, cilantro, and roja salsa.',
    price: '$4.75',
    tag: 'Fan favorite',
  },
  {
    name: 'Al pastor',
    description: 'Adobo-marinated pork, grilled pineapple, and salsa verde.',
    price: '$4.25',
  },
  {
    name: 'Barbacoa',
    description: 'Slow-braised beef with onion and fresh cilantro.',
    price: '$4.75',
  },
  {
    name: 'Grilled Chicken',
    description: 'Marinated chicken, pico de gallo, and lime.',
    price: '$4.25',
  },
]

function BrandMark() {
  return (
    <a href="#home" className="brand-mark" aria-label="Taco 911 — home">
      <span className="brand-icon" aria-hidden="true">
        <span>911</span>
      </span>
      <span className="brand-name">TACO <b>911</b></span>
    </a>
  )
}

function SiteHeader() {
  return (
    <header className="site-header">
      <div className="header-inner">
        <BrandMark />
        <nav aria-label="Main navigation" className="desktop-nav">
          <a href="#menu">Menu</a>
          <a href="#location">Find us</a>
        </nav>
        <a className="header-call" href="tel:+17133450101">
          <Phone aria-hidden="true" />
          <span>Call now</span>
        </a>
      </div>
    </header>
  )
}

function HeroSection() {
  return (
    <section className="hero" id="home" aria-labelledby="hero-title">
      <Image
        className="hero-photo"
        src="/taco-911-hero.png"
        alt="Street-style carne asada tacos with onion, cilantro, and lime"
        fill
        priority
        sizes="100vw"
      />
      <div className="hero-shade" aria-hidden="true" />
      <div className="hero-content">
        <div className="open-badge">
          <span className="open-dot" aria-hidden="true" />
          <Clock3 aria-hidden="true" />
          <span>Open Late: Thu–Sun until 4:00 AM</span>
        </div>
        <p className="eyebrow"><Flame aria-hidden="true" /> AUSTIN, TEXAS · 6TH STREET</p>
        <h1 id="hero-title"><span className="headline-plain">Hot tacos.</span><br /><span className="headline-accent">Late nights.</span></h1>
        <p className="hero-copy">Street tacos, made fresh to order. Bring your appetite—we&apos;ll take it from here.</p>
        <div className="hero-actions">
          <a className="button-primary" href="tel:+17133450101">
            <Phone aria-hidden="true" />
            Call to Order
            <ArrowUpRight aria-hidden="true" className="button-arrow" />
          </a>
          <a className="button-secondary" href={mapUrl} target="_blank" rel="noreferrer">
            <MapPin aria-hidden="true" />
            Get Directions
          </a>
        </div>
        <a className="hero-location" href={mapUrl} target="_blank" rel="noreferrer">
          <MapPin aria-hidden="true" />
          <span>106 E 6th St, Austin, TX</span>
          <ArrowUpRight aria-hidden="true" />
        </a>
        <div className="hero-proof"><Sparkles aria-hidden="true" /><span>Fresh off the grill. Served late.</span></div>
      </div>
      <a href="#menu" className="scroll-cue" aria-label="Scroll down for the menu">
        <span>SCROLL DOWN FOR THE MENU</span><ArrowDown aria-hidden="true" />
      </a>
      <span className="hero-stamp" aria-hidden="true">TACOS<br />AFTER<br />DARK</span>
    </section>
  )
}

function MenuSection() {
  return (
    <section className="menu-section section-wrap" id="menu" aria-labelledby="menu-title">
      <div className="section-heading">
        <div>
          <p className="eyebrow"><span className="eyebrow-line" /> THE MENU</p>
          <h2 id="menu-title">Small tacos.<br /><span>Big nights.</span></h2>
        </div>
        <p className="section-intro">Warm tortillas, generous fillings, and salsa that keeps you coming back. Pick a favorite and order at the counter.</p>
      </div>
      <div className="menu-feature">
        <div className="menu-photo-wrap">
          <Image
            src="/taco-911-specials.png"
            alt="A spread of street tacos with salsa and lime"
            fill
            sizes="(max-width: 700px) 100vw, 42vw"
          />
          <span className="photo-label"><Flame aria-hidden="true" /> FRESH OFF THE GRILL</span>
        </div>
        <div className="menu-list" aria-label="Tacos">
          {tacos.map((taco, index) => (
            <article className="menu-item" key={taco.name}>
              <div className="menu-item-top">
                <div className="menu-item-title">
                  <span className="menu-number">0{index + 1}</span>
                  <h3>{taco.name}</h3>
                  {taco.tag && <span className="popular-tag">{taco.tag}</span>}
                </div>
                <span className="menu-price">{taco.price}</span>
              </div>
              <p>{taco.description}</p>
            </article>
          ))}
          <p className="menu-footnote">* Placeholder prices. Ask about today&apos;s specials.</p>
        </div>
      </div>
      <div className="menu-bottom-note"><span>A GREAT NIGHT STARTS WITH SALSA.</span><span>ONE MORE. <b>YOU DESERVE IT.</b></span></div>
    </section>
  )
}

function LocationSection() {
  return (
    <section className="location-section" id="location" aria-labelledby="location-title">
      <div className="location-inner section-wrap">
        <div className="location-copy">
          <p className="eyebrow"><span className="eyebrow-line" /> RIGHT ON 6TH STREET</p>
          <h2 id="location-title">We&apos;ll be<br /><span>right here.</span></h2>
          <p className="location-address"><MapPin aria-hidden="true" />106 E 6th St, Austin, TX</p>
          <p className="location-detail">Right in the middle of the action. Stop by after the show, on your way home, or whenever late-night cravings hit.</p>
          <a className="button-primary directions-cta" href={mapUrl} target="_blank" rel="noreferrer">
            <MapPin aria-hidden="true" />
            Get Directions
            <ArrowUpRight aria-hidden="true" className="button-arrow" />
          </a>
          <div className="hours-note"><Clock3 aria-hidden="true" /><span><b>Open Late: Thu–Sun until 4:00 AM</b><small>Come by late. The kitchen&apos;s open.</small></span></div>
        </div>
        <div className="map-frame">
          <iframe
            title="Map — Taco 911, 106 E 6th St, Austin, TX"
            src="https://maps.google.com/maps?q=106%20E%206th%20St%2C%20Austin%2C%20TX&t=&z=16&ie=UTF8&iwloc=&output=embed"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            allowFullScreen
          />
          <div className="map-caption"><MapPin aria-hidden="true" /><span>106 E 6th St <small>AUSTIN, TEXAS</small></span><a href={mapUrl} target="_blank" rel="noreferrer" aria-label="Open location in Google Maps"><ArrowUpRight aria-hidden="true" /></a></div>
        </div>
      </div>
    </section>
  )
}

function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="footer-inner section-wrap">
        <BrandMark />
        <p>Here to satisfy late-night cravings.</p>
        <a href="tel:+17133450101"><Phone aria-hidden="true" /> (713) 345-0101</a>
        <span className="copyright">© 2026 TACO 911 · AUSTIN, TX</span>
      </div>
    </footer>
  )
}

export function Taco911Site() {
  return (
    <>
      <SiteHeader />
      <main>
        <HeroSection />
        <MenuSection />
        <LocationSection />
      </main>
      <SiteFooter />
    </>
  )
}
