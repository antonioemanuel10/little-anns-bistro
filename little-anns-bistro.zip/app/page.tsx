import { Taco911Site } from '@/components/taco-911-site'

export default function Page() {
  return <Taco911Site />
}
